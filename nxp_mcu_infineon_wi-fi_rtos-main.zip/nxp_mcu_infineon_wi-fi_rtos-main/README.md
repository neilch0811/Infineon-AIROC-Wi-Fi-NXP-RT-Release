# NXP_MCU_infineon_Wi-Fi_RTOS



## Getting started

Follow the Getting started with AIROC™ CYW43012/ CYW43022 Wi-Fi / Bluetooth® Combo in RTOS
IMXRT600-AUD-EVK for quick setup of the above project.

# Release history

 Version | Description of change
 ------- | ---------------------
 1.0.0   | Wi-Fi Scan Ping and Join
 
